using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IocDemo.Api.Services.IServices;

namespace IocDemo.Api.Services
{
    public class Role : IRole
    {
        
    }
}